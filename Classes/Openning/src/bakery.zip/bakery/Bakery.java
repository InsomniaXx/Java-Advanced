package Openning.src.bakery;

import groomingSalon.Pet;

import java.util.ArrayList;
import java.util.List;

public class Bakery {
    private String name;
    private int capacity;
    private List<Employee> employees;

    public Bakery(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.employees = new ArrayList<>();
    }

    public void add(Employee employee) {
        if (capacity > employees.size()) {
            employees.add(employee);
        }
    }
    public boolean remove(String name) {
        boolean isRemoved = false;
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getName().equals(name)) {
                isRemoved = true;
                employees.remove(i);
            }
        }
        return isRemoved;
    }
    public Employee getOldestEmployee() {
        Employee oldestEmployee = null;
        int oldestAge = Integer.MIN_VALUE;

        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getAge() > oldestAge) {
                oldestAge = employees.get(i).getAge();
                oldestEmployee = new Employee(employees.get(i).getName(),
                        employees.get(i).getAge(),
                        employees.get(i).getCountry());
            }
        }
        return oldestEmployee;
    }

    public Employee getEmployee(String name) {
        Employee employee = null;
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getName().equals(name)) {
                employee = new Employee(employees.get(i).getName(),
                        employees.get(i).getAge(),
                        employees.get(i).getCountry());
            }
        }
        return employee;
    }

    public int getCount() {
        return employees.size();
    }

    public String report() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Employees working at Bakery " + this.name + ":").append("\n");
        for (int i = 0; i < employees.size(); i++) {
            stringBuilder.append(employees.get(i));
            if (i + 1 < employees.size()) {
                stringBuilder.append("\n");
            }
        }

        return stringBuilder.toString();
    }

}
